package ch.piiwii.tvphone;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StatFs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class DeviceApi {
    static final String BASE = "https://piiwii.ch/wp-json/geektv/v1/";
    private static final String PREFS = "piiwii_tv_phone_sync";
    private static final String TOKEN = "token";
    private static final String DEVICE_ID = "device_id";
    private static final String DEVICE_NAME = "device_name";
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();

    interface Callback { void done(JSONObject result, Exception error); }

    private DeviceApi() {}

    static boolean isPaired(Context c) { return !prefs(c).getString(TOKEN, "").isEmpty(); }
    static String token(Context c) { return prefs(c).getString(TOKEN, ""); }
    static String deviceId(Context c) { return prefs(c).getString(DEVICE_ID, ""); }
    static String deviceName(Context c) { return prefs(c).getString(DEVICE_NAME, Build.MANUFACTURER + " " + Build.MODEL); }

    static void unpair(Context c) {
        prefs(c).edit().clear().apply();
        ScheduleSyncJobService.disable(c);
    }

    static void pairAsync(Context c, String code, Callback cb) {
        EXEC.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("code", code == null ? "" : code.replaceAll("\\D+", ""));
                body.put("device_name", Build.MANUFACTURER + " " + Build.MODEL);
                body.put("device_type", "mobile");
                JSONObject result = request("POST", "pair/exchange", "", body);
                String tok = result.optString("token", "");
                JSONObject d = result.optJSONObject("device");
                String id = d == null ? "" : d.optString("id", "");
                String name = d == null ? Build.MODEL : d.optString("name", Build.MODEL);
                if (tok.isEmpty() || id.isEmpty()) throw new Exception("Association refusée");
                prefs(c).edit().putString(TOKEN, tok).putString(DEVICE_ID, id).putString(DEVICE_NAME, name).apply();
                ScheduleSyncJobService.enable(c);
                ScheduleSyncJobService.runOnce(c);
                try { sendDeviceStatus(c); } catch (Exception ignored) { }
                cb.done(result, null);
            } catch (Exception e) { cb.done(null, e); }
        });
    }

    static JSONObject createSchedule(Context c, String channelId, String title, String epgId,
                                     long startMs, long endMs, String scope, String source) throws Exception {
        JSONObject b = new JSONObject();
        b.put("channel_id", channelId);
        b.put("title", title);
        b.put("epg_id", epgId == null ? "" : epgId);
        b.put("start", startMs / 1000L);
        b.put("end", endMs / 1000L);
        b.put("margin_before", 2);
        b.put("margin_after", 5);
        b.put("storage_scope", "cloud".equals(scope) ? "cloud" : "local");
        b.put("source", source == null ? "phone" : source);
        return request("POST", "schedules", tokenRequired(c), b).optJSONObject("schedule");
    }

    static JSONArray schedules(Context c) throws Exception {
        JSONObject r = request("GET", "schedules", tokenRequired(c), null);
        JSONArray a = r.optJSONArray("schedules");
        return a == null ? new JSONArray() : a;
    }

    static void updateSchedule(Context c, String remoteId, String state, String recordingId, String error) throws Exception {
        if (remoteId == null || remoteId.isEmpty()) return;
        JSONObject b = new JSONObject();
        b.put("status", state);
        b.put("recording_id", recordingId == null ? "" : recordingId);
        b.put("error", error == null ? "" : error);
        request("POST", "schedules/" + safeId(remoteId), tokenRequired(c), b);
    }

    static JSONObject startCloud(Context c, String channelId, String title, long startMs, long endMs, String scheduleId) throws Exception {
        JSONObject b = new JSONObject();
        b.put("channel_id", channelId);
        b.put("title", title);
        b.put("start", startMs / 1000L);
        b.put("expected_end", endMs / 1000L);
        b.put("schedule_id", scheduleId == null ? "" : scheduleId);
        return request("POST", "recording-session/start", tokenRequired(c), b);
    }

    static JSONObject pumpCloud(Context c, String sessionId) throws Exception {
        return request("POST", "recording-session/" + safeId(sessionId) + "/pump", tokenRequired(c), new JSONObject());
    }

    static JSONObject finishCloud(Context c, String sessionId, String state, String error) throws Exception {
        JSONObject b = new JSONObject();
        b.put("state", state == null ? "complete" : state);
        b.put("error", error == null ? "" : error);
        return request("POST", "recording-session/" + safeId(sessionId) + "/finish", tokenRequired(c), b);
    }

    static void pushLocalRecording(Context c, RecordingEntry r) throws Exception {
        if (!isPaired(c) || r == null) return;
        JSONObject row = new JSONObject();
        row.put("id", r.id); row.put("channel_id", r.channelId); row.put("channel_name", r.channelName);
        row.put("title", r.title); row.put("start", r.startMs / 1000L); row.put("expected_end", r.expectedEndMs / 1000L);
        row.put("end", r.endMs > 0 ? r.endMs / 1000L : 0L); row.put("state", r.state); row.put("bytes", r.bytes);
        row.put("storage_scope", "local"); row.put("category", "Téléphone"); row.put("error", r.error);
        row.put("updated_at", Math.max(1L, r.updatedAtMs / 1000L));
        JSONArray a = new JSONArray(); a.put(row);
        JSONObject body = new JSONObject(); body.put("recordings", a);
        request("POST", "recordings", tokenRequired(c), body);
    }

    static void sendDeviceStatus(Context c) throws Exception {
        if (!isPaired(c)) return;
        JSONObject b = new JSONObject();
        b.put("app_version", "0.5.0"); b.put("version_code", 5); b.put("can_record", true);
        long free = 0, total = 0;
        try { StatFs s = new StatFs(c.getFilesDir().getAbsolutePath()); free = s.getAvailableBytes()/1048576L; total = s.getTotalBytes()/1048576L; } catch (Exception ignored) {}
        b.put("free_space_mb", free); b.put("total_space_mb", total); b.put("sync_mode", "job-15m"); b.put("sync_interval_min", 15);
        JSONArray caps = new JSONArray(); for (String x : new String[]{"live","epg","dvr","schedule","recordings","sync","cloud"}) caps.put(x); b.put("capabilities", caps);
        request("POST", "device/status", tokenRequired(c), b);
    }

    static JSONObject request(String method, String path, String token, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(25000); c.setRequestMethod(method);
        c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "PiiWii-TV-Phone/0.5.0 Android");
        if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) {
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
        }
        int code = c.getResponseCode(); InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line=r.readLine())!=null) sb.append(line); }
        c.disconnect(); JSONObject result = sb.length() == 0 ? new JSONObject() : new JSONObject(sb.toString());
        if (code < 200 || code >= 300) throw new Exception(result.optString("message", "HTTP " + code));
        return result;
    }

    private static String tokenRequired(Context c) throws Exception { String t=token(c); if(t.isEmpty()) throw new Exception("Téléphone non associé à PiiWii TV"); return t; }
    private static String safeId(String s) { return s == null ? "" : s.replaceAll("[^A-Za-z0-9_.-]", ""); }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
}
