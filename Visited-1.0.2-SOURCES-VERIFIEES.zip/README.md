# Visited 1.0.0-beta35 — stabilité My Maps

- Conservation de la carte Google My Maps originale, affichée par la WebView ; bouton « + » ouvrant son éditeur officiel en Custom Tab.
- Suppression du code mort de l’ancien formulaire local `PlaceCreator`. Correction d’un crash dans `PlacesActivity.onRequestPermissionsResult` (appel à un objet toujours `null`).
- Retour Android : sort désormais de la vue carte, sans parcourir un historique Google invisible.
- Délai de chargement de 30 s avec l’écran existant « Réessayer » si la carte reste bloquée.
- Import KML/KMZ limité à 16 Mio pour empêcher l’épuisement de mémoire. Les échecs de synchronisation conservent le cache.
- Doublons locaux devenus des lieux My Maps réconciliés dans la base de données et compteurs de l’accueil rendus plus explicites.
- L’aide précise comment essayer la version ordinateur de l’éditeur mobile dans Chrome ; cela ne garantit pas que My Maps fonctionne sur Android.
- Permissions de localisation supprimées, car le système GPS local n’est plus employé.
- ApplicationId `ch.piiwii.visited.beta35test` (debug : `.debug`), versionCode 35, versionName `1.0.0-beta35-stability`.

**Limite :** aucune API publique ne permet de créer directement des repères dans le document My Maps par le SDK Android. L’utilisateur doit réussir l’édition dans l’éditeur officiel Google, selon ses capacités mobiles.
