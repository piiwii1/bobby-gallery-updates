package ch.piiwii.visited;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileActivity extends Activity {
    private static final int REQUEST_EXPORT = 7701;
    private static final int REQUEST_IMPORT = 7702;
    private PlaceDb db;
    private boolean pendingEditorReturn = false;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        db = new PlaceDb(this);
        BottomNav.setup(this, BottomNav.PROFILE);
        findViewById(R.id.btnSyncMyMaps).setOnClickListener(v -> syncMyMaps());
        findViewById(R.id.btnOpenMyMaps).setOnClickListener(v -> openMyMaps());
        findViewById(R.id.btnExportDrive).setOnClickListener(v -> exportToDrive());
        findViewById(R.id.btnImportDrive).setOnClickListener(v -> importFromDrive());
        refreshCounts();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null) refreshCounts();
        if (pendingEditorReturn) {
            pendingEditorReturn = false;
            syncMyMaps();
        }
        BottomNav.setup(this, BottomNav.PROFILE);
    }

    private void refreshCounts() {
        int myMaps = 0;
        int local = 0;
        for (Place p : db.all()) {
            if ("mymaps".equals(p.source)) myMaps++;
            else local++;
        }
        ((TextView)findViewById(R.id.profileMapCount)).setText(myMaps + " points Places Visited · " + local + " ajouts application");
    }

    private void syncMyMaps() {
        Toast.makeText(this, "Synchronisation Places Visited…", Toast.LENGTH_SHORT).show();
        findViewById(R.id.btnSyncMyMaps).setEnabled(false);
        io.execute(() -> {
            try {
                List<Place> imported = MyMapsImporter.download();
                if (!imported.isEmpty()) db.replaceMyMaps(imported);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    findViewById(R.id.btnSyncMyMaps).setEnabled(true);
                    refreshCounts();
                    Toast.makeText(this, imported.size() + " points Places Visited synchronisés", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    findViewById(R.id.btnSyncMyMaps).setEnabled(true);
                    Toast.makeText(this, "Places Visited indisponible. Tes lieux enregistrés restent conservés.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void openMyMaps() {
Intent intent = new Intent(this, MainActivity.class);
intent.putExtra(MainActivity.EXTRA_OPEN_MAP, true);
intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
startActivity(intent);
}

    private void exportToDrive() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.google-earth.kml+xml");
        i.putExtra(Intent.EXTRA_TITLE, "Visited-mes-lieux.kml");
        try { startActivityForResult(i, REQUEST_EXPORT); }
        catch (Exception e) { Toast.makeText(this, "Gestionnaire de fichiers indisponible", Toast.LENGTH_LONG).show(); }
    }

    private void importFromDrive() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.google-earth.kml+xml", "application/xml", "text/xml", "application/octet-stream"});
        try { startActivityForResult(i, REQUEST_IMPORT); }
        catch (Exception e) { Toast.makeText(this, "Gestionnaire de fichiers indisponible", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode != REQUEST_EXPORT && requestCode != REQUEST_IMPORT) return;
        Uri documentUri = data.getData();
        io.execute(() -> {
            try {
                int count = requestCode == REQUEST_EXPORT
                        ? DriveKmlBackup.exportLocal(getContentResolver(), documentUri, db)
                        : DriveKmlBackup.importLocal(getContentResolver(), documentUri, db);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    refreshCounts();
                    Toast.makeText(this, requestCode == REQUEST_EXPORT
                            ? count + " lieux sauvegardés (fichier KML)"
                            : count + " nouveaux lieux importés", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Opération impossible : " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show());
            }
        });
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        if (db != null) db.close();
        super.onDestroy();
    }
}
