package ch.piiwii.visited;

/** Shared marker-style preferences. The map itself is Google Maps in beta16+. */
public final class VisitedMapView {
    private VisitedMapView() {}
    public static final String PREFS = "piiwii_visited_settings";
    public static final String PREF_MARKER_STYLE = "marker_style";
    public static final int STYLE_DOT = 0;
    public static final int STYLE_PIN = 1;
    public static final int STYLE_TARGET = 2;
    public static final int STYLE_DIAMOND = 3;
}
