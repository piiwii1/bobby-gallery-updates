package ch.piiwii.visited;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.Toast;

public class MarkerSettingsButton extends Button {
    public MarkerSettingsButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOnClickListener(v -> showSettings());
    }

    private void showSettings() {
        final String[] choices = {
                "●  Point rouge",
                "📍  Épingle rouge",
                "◎  Cible rouge",
                "◆  Losange rouge"
        };
        int current = getContext().getSharedPreferences(VisitedMapView.PREFS, Context.MODE_PRIVATE)
                .getInt(VisitedMapView.PREF_MARKER_STYLE, VisitedMapView.STYLE_DOT);

        new AlertDialog.Builder(getContext())
                .setTitle("Paramètres · Style des repères")
                .setSingleChoiceItems(choices, current, (dialog, which) -> {
                    getContext().getSharedPreferences(VisitedMapView.PREFS, Context.MODE_PRIVATE)
                            .edit().putInt(VisitedMapView.PREF_MARKER_STYLE, which).apply();
                    dialog.dismiss();
                    Activity activity = unwrapActivity(getContext());
                    if (activity instanceof MainActivity) ((MainActivity) activity).refreshMarkerStyle();
                    Toast.makeText(getContext(), "Style des repères modifié", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Fermer", null)
                .show();
    }

    private Activity unwrapActivity(Context context) {
        Context c = context;
        while (c instanceof ContextWrapper) {
            if (c instanceof Activity) return (Activity)c;
            Context base = ((ContextWrapper)c).getBaseContext();
            if (base == c) break;
            c = base;
        }
        return c instanceof Activity ? (Activity)c : null;
    }
}
