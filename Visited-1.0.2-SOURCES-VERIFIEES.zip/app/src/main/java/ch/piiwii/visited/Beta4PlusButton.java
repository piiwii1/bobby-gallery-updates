package ch.piiwii.visited;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.PopupMenu;

/** The plus button is never allowed to call a missing method by reflection. */
public final class Beta4PlusButton extends Button {
    public Beta4PlusButton(Context c, AttributeSet attrs) { super(c, attrs); }

    @Override public boolean performClick() {
        // Respect the caller's explicit click listener and never launch twice.
        return super.performClick();
    }

    private void openPlaceCreator(boolean locate) {
        Activity a = unwrap(getContext());
        if (a == null) return;
        if (a instanceof MainActivity) {
            ((MainActivity)a).openAdd(locate);
        } else if (a instanceof PlacesActivity) {
            ((PlacesActivity)a).openAdd(locate);
        } else {
            Intent i = new Intent(a, PlacesActivity.class);
            i.putExtra(PlacesActivity.EXTRA_START_ADD, true);
            i.putExtra(PlacesActivity.EXTRA_START_GPS, locate);
            a.startActivity(i);
        }
    }

    private Activity unwrap(Context c) {
        while (c instanceof ContextWrapper) {
            if (c instanceof Activity) return (Activity)c;
            Context next = ((ContextWrapper)c).getBaseContext();
            if (next == c) break;
            c = next;
        }
        return c instanceof Activity ? (Activity)c : null;
    }
}
