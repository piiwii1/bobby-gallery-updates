package ch.piiwii.visited;

import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MyMapsImporter {
    private MyMapsImporter() {}

    public static final String MAP_ID = "1juUMJwmwpBGGrLrkBnnAfm0cqPEvjTRm";
    public static final String EDIT_URL = "https://www.google.com/maps/d/edit?mid=" + MAP_ID;
    public static final String SHARE_URL = EDIT_URL + "&usp=sharing";
    public static final String VIEW_URL = "https://www.google.com/maps/d/embed?mid=" + MAP_ID + "&ehbc=2E312F";
    // Protect the app from oversized KML/KMZ exports and decompression bombs.
    private static final int MAX_EXPORT_BYTES = 16 * 1024 * 1024;
    private static final String[] EXPORT_URLS = new String[]{
            "https://www.google.com/maps/d/kml?mid=" + MAP_ID + "&forcekml=1",
            "https://www.google.com/maps/d/kml?mid=" + MAP_ID + "&forcekml=0",
            "https://www.google.com/maps/d/u/0/kml?mid=" + MAP_ID + "&forcekml=1",
            "https://www.google.com/maps/d/kml?mid=" + MAP_ID
    };

    public static final class SyncException extends Exception {
        public SyncException(String message) { super(message); }
    }

    public static List<Place> download() throws Exception {
        Exception last = null;
        for (String u : EXPORT_URLS) {
            try {
                byte[] data = fetch(u);
                byte[] kml = unwrapKmzIfNeeded(data);
                List<Place> parsed = parse(new ByteArrayInputStream(kml));
                if (!parsed.isEmpty()) return parsed;
                last = new SyncException("La carte Places Visited a répondu, mais aucun point n'a été trouvé dans l'export.");
            } catch (SyncException e) {
                last = e;
            } catch (Exception e) {
                last = e;
            }
        }
        if (last instanceof SyncException) throw last;
        throw new SyncException("Google Places Visited n'autorise pas l'export automatique de cette carte. Dans Places Visited, vérifie le partage et autorise l'accès via le lien, puis relance la synchronisation.");
    }

    private static byte[] fetch(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "PiiWiiVisited/1.0 Android");
        c.setRequestProperty("Accept", "application/vnd.google-earth.kml+xml, application/vnd.google-earth.kmz, application/xml, text/xml, */*");
        try {
            int code = c.getResponseCode();
            if (code == 401 || code == 403) {
                throw new SyncException("Google Places Visited refuse l'accès sans autorisation. Ouvre ta carte Places Visited, active le partage par lien, puis réessaie.");
            }
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
            try (InputStream in = new BufferedInputStream(c.getInputStream()); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (out.size() + n > MAX_EXPORT_BYTES)
                        throw new SyncException("Export KML trop volumineux pour une synchronisation sûre.");
                    out.write(buf, 0, n);
                }
                byte[] data = out.toByteArray();
                if (looksLikeHtml(data)) {
                    throw new SyncException("Google Places Visited renvoie une page de connexion au lieu du KML. La carte doit autoriser l'accès via le lien pour être synchronisée automatiquement.");
                }
                return data;
            }
        } finally {
            c.disconnect();
        }
    }

    private static boolean looksLikeHtml(byte[] data) {
        int len = Math.min(data.length, 800);
        String head = new String(data, 0, len, StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
        return head.contains("<html") || head.contains("<!doctype html") || head.contains("accounts.google.com");
    }

    private static byte[] unwrapKmzIfNeeded(byte[] data) throws Exception {
        if (data.length >= 2 && data[0] == 'P' && data[1] == 'K') {
            try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(data))) {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null) {
                    if (!entry.isDirectory() && entry.getName().toLowerCase(Locale.ROOT).endsWith(".kml")) {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = zin.read(buf)) > 0) {
                            if (out.size() + n > MAX_EXPORT_BYTES)
                                throw new SyncException("Le KML décompressé dépasse la limite de sécurité.");
                            out.write(buf, 0, n);
                        }
                        return out.toByteArray();
                    }
                }
            }
            throw new SyncException("Le fichier KMZ reçu ne contient aucun KML lisible.");
        }
        return data;
    }

    private static List<Place> parse(InputStream in) throws Exception {
        List<Place> out = new ArrayList<>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(in, "UTF-8");
        boolean inPlacemark = false;
        boolean inPoint = false;
        String name = null;
        String coords = null;
        int event = p.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                String tag = p.getName();
                if ("Placemark".equalsIgnoreCase(tag)) {
                    inPlacemark = true;
                    inPoint = false;
                    name = null;
                    coords = null;
                } else if (inPlacemark && "name".equalsIgnoreCase(tag)) {
                    name = p.nextText();
                } else if (inPlacemark && "Point".equalsIgnoreCase(tag)) {
                    inPoint = true;
                } else if (inPlacemark && inPoint && "coordinates".equalsIgnoreCase(tag)) {
                    coords = p.nextText();
                }
            } else if (event == XmlPullParser.END_TAG) {
                String tag = p.getName();
                if ("Point".equalsIgnoreCase(tag)) inPoint = false;
                if ("Placemark".equalsIgnoreCase(tag)) {
                    if (coords != null) {
                        String first = coords.trim().split("\\s+")[0];
                        String[] parts = first.split(",");
                        if (parts.length >= 2) {
                            try {
                                double lon = Double.parseDouble(parts[0]);
                                double lat = Double.parseDouble(parts[1]);
                                String n = name == null || name.trim().isEmpty() ? "Lieu visité" : name.trim();
                                out.add(new Place(0, n, lat, lon, "mymaps"));
                            } catch (NumberFormatException ignored) { }
                        }
                    }
                    inPlacemark = false;
                }
            }
            event = p.next();
        }
        return out;
    }
}
