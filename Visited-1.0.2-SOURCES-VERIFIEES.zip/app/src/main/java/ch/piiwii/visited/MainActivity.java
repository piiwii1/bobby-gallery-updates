package ch.piiwii.visited;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    public static final String EXTRA_OPEN_MAP="ch.piiwii.visited.OPEN_MAP";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final AtomicBoolean syncing=new AtomicBoolean(false);
    private PlaceDb db;
    private TextView info;
    private boolean editorOpen=false, pausedSinceOpen=false, autoLaunchPending=false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db=new PlaceDb(this);
        info=findViewById(R.id.mapInfo);
        findViewById(R.id.btnOpenEditor).setOnClickListener(v->openEditor());
        findViewById(R.id.btnSyncPlaces).setOnClickListener(v->syncPlaces(false));
        if(b==null) {
            autoLaunchPending=true;
            handler.postDelayed(()->{
                if(autoLaunchPending && !isFinishing() && !isDestroyed()) openEditor();
                autoLaunchPending=false;
            },180L);
        }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent.getBooleanExtra(EXTRA_OPEN_MAP,false)) {
            handler.post(()->{ if(!isFinishing()) openEditor(); });
        }
    }
    public void openEditor() {
        autoLaunchPending=false;
        if(editorOpen || isFinishing() || isDestroyed()) return;
        if(MyMapsEditor.open(this)) {
            editorOpen=true;
            pausedSinceOpen=false;
            info.setText("Ta carte My Maps est ouverte. Ferme la fenêtre Google pour revenir à Visited.");
        } else {
            new AlertDialog.Builder(this).setTitle("Carte indisponible")
                .setMessage("Un navigateur compatible est nécessaire pour modifier ta carte Google My Maps.")
                .setPositiveButton("Réessayer",(d,w)->openEditor())
                .setNegativeButton("Fermer",null).show();
        }
    }
    private void syncPlaces(boolean quiet) {
        if(!syncing.compareAndSet(false,true)) return;
        io.execute(()->{
            boolean ok=false;
            try {
                List<Place> places=MyMapsImporter.download();
                if(!places.isEmpty()) { db.replaceMyMaps(places); ok=true; }
            } catch(Exception ignored) {
            } finally { syncing.set(false); }
            final boolean success=ok;
            runOnUiThread(()->{
                if(isFinishing() || isDestroyed()) return;
                if(success) info.setText("Carte originale conservée · "+db.count()+" lieux en cache.");
                else if(!quiet) Toast.makeText(this,"Carte conservée. Statistiques temporairement indisponibles.",Toast.LENGTH_LONG).show();
            });
        });
    }
    @Override protected void onResume() {
        super.onResume();
        if(editorOpen && pausedSinceOpen) {
            editorOpen=false; pausedSinceOpen=false; syncPlaces(true);
        }
    }
    @Override protected void onPause() {
        if(editorOpen) pausedSinceOpen=true;
        super.onPause();
    }
    public void refreshMarkerStyle(){openEditor();}
    public void openAdd(boolean gps){openEditor();}
    @Override protected void onDestroy(){
        autoLaunchPending=false;
        handler.removeCallbacksAndMessages(null);
        io.shutdownNow();
        if(db!=null) db.close();
        super.onDestroy();
    }
}
