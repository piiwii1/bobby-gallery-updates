package ch.piiwii.visited;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.SystemClock;
import android.widget.RemoteViews;
import android.widget.Toast;

import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;

public final class MyMapsEditor {
    private static long lastTapMs;
    private MyMapsEditor() {}

    public static synchronized boolean open(Activity activity) {
        long now=SystemClock.elapsedRealtime();
        if(now-lastTapMs < 800L) return true;
        lastTapMs=now;
        Uri editor=Uri.parse(MyMapsImporter.EDIT_URL);
        try {
            RemoteViews footer=new RemoteViews(activity.getPackageName(),R.layout.editor_bottom_nav);
            footer.setOnClickPendingIntent(R.id.editorNavHome, navIntent(activity,HomeActivity.class,101));
            footer.setOnClickPendingIntent(R.id.editorNavPlaces, navIntent(activity,PlacesActivity.class,102));
            footer.setOnClickPendingIntent(R.id.editorNavProfile, navIntent(activity,ProfileActivity.class,103));

            CustomTabColorSchemeParams colors=new CustomTabColorSchemeParams.Builder()
                .setToolbarColor(Color.rgb(24,24,47))
                .setNavigationBarColor(Color.rgb(16,17,32))
                .build();
            CustomTabsIntent tab=new CustomTabsIntent.Builder()
                .setDefaultColorSchemeParams(colors)
                .setCloseButtonIcon(closeIcon(activity))
                .setShowTitle(true)
                .setShareState(CustomTabsIntent.SHARE_STATE_OFF)
                .setSecondaryToolbarViews(footer,null,null)
                .build();
            tab.intent.setPackage("com.android.chrome");
            try {
                tab.launchUrl(activity,editor);
                return true;
            } catch(ActivityNotFoundException noChrome) {
                tab.intent.setPackage(null);
                tab.launchUrl(activity,editor);
                return true;
            }
        } catch(Exception e) {
            return openBrowser(activity,editor,true);
        }
    }

    private static PendingIntent navIntent(Activity activity,Class<?> target,int code) {
        Intent intent=new Intent(activity,target);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(activity,code,intent,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    public static boolean openBrowser(Activity activity,Uri url,boolean notice) {
        try {
            Intent intent=new Intent(Intent.ACTION_VIEW,url);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            activity.startActivity(intent);
            if(notice) Toast.makeText(activity,
                "Ce navigateur n'affiche pas la barre Visited : retour via Android.",Toast.LENGTH_LONG).show();
            return true;
        } catch(Exception e) {
            Toast.makeText(activity,"Impossible d'ouvrir ta carte My Maps.",Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private static Bitmap closeIcon(Activity activity) {
        int side=Math.round(24*activity.getResources().getDisplayMetrics().density);
        Bitmap bitmap=Bitmap.createBitmap(side,side,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(Math.max(2f,side/12f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        float inset=side*0.25f;
        canvas.drawLine(inset,inset,side-inset,side-inset,paint);
        canvas.drawLine(side-inset,inset,inset,side-inset,paint);
        return bitmap;
    }
}
