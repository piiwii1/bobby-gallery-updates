package ch.piiwii.visited;

import android.content.ContentResolver;
import android.net.Uri;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** Interoperable KML backup using Android's Storage Access Framework (Google Drive picker). */
final class DriveKmlBackup {
    private DriveKmlBackup() {}

    static int exportLocal(ContentResolver resolver, Uri uri, PlaceDb db) throws Exception {
        List<Place> places = db.all();
        StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>Visited - mes lieux</name>\n");
        int count = 0;
        for (Place p : places) {
            if (!"local".equals(p.source)) continue;
            xml.append("<Placemark><name>");
            escape(xml, p.name);
            xml.append("</name><Point><coordinates>")
                    .append(String.format(Locale.US, "%.8f,%.8f,0", p.lon, p.lat))
                    .append("</coordinates></Point></Placemark>\n");
            count++;
        }
        xml.append("</Document></kml>");
        try (OutputStream out = resolver.openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("Document inaccessible en écriture");
            out.write(xml.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
        return count;
    }

    static int importLocal(ContentResolver resolver, Uri uri, PlaceDb db) throws Exception {
        try (InputStream raw = resolver.openInputStream(uri)) {
            if (raw == null) throw new IllegalStateException("Document introuvable");
            InputStream in = new BufferedInputStream(raw);
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(in, "UTF-8");
            int event = parser.getEventType();
            boolean placemark = false, point = false;
            String name = null, coordinates = null;
            int added = 0, examined = 0;
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    String tag = parser.getName();
                    if ("Placemark".equalsIgnoreCase(tag)) {
                        placemark = true; point = false; name = null; coordinates = null;
                    } else if (placemark && "name".equalsIgnoreCase(tag)) {
                        name = parser.nextText();
                    } else if (placemark && "Point".equalsIgnoreCase(tag)) {
                        point = true;
                    } else if (placemark && point && "coordinates".equalsIgnoreCase(tag)) {
                        coordinates = parser.nextText();
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    String tag = parser.getName();
                    if ("Point".equalsIgnoreCase(tag)) point = false;
                    if ("Placemark".equalsIgnoreCase(tag)) {
                        examined++;
                        if (examined > 20000) throw new IllegalArgumentException("Trop de lieux dans le fichier");
                        if (coordinates != null) {
                            String[] parts = coordinates.trim().split("\\s+")[0].split(",");
                            if (parts.length >= 2) {
                                try {
                                    double lon = Double.parseDouble(parts[0]);
                                    double lat = Double.parseDouble(parts[1]);
                                    if (Double.isFinite(lat) && Double.isFinite(lon) &&
                                            lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                                        long id = db.add(name == null || name.trim().isEmpty() ? "Lieu visité" : name, lat, lon, "local");
                                        if (id != -1) added++;
                                    }
                                } catch (NumberFormatException ignored) { }
                            }
                        }
                        placemark = false;
                    }
                }
                event = parser.next();
            }
            return added;
        }
    }

    private static void escape(StringBuilder xml, String text) {
        if (text == null) return;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '&') xml.append("&amp;");
            else if (c == '<') xml.append("&lt;");
            else if (c == '>') xml.append("&gt;");
            else if (c == '"') xml.append("&quot;");
            else if (c != 0) xml.append(c);
        }
    }
}
