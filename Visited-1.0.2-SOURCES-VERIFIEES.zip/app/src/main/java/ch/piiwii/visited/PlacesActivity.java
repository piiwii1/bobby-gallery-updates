package ch.piiwii.visited;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class PlacesActivity extends Activity {
    public static final String EXTRA_START_ADD = "ch.piiwii.visited.START_ADD";
    public static final String EXTRA_START_GPS = "ch.piiwii.visited.START_GPS";
    private PlaceDb db;
    private ListView list;
    private TextView title;
    private boolean pendingEditorReturn = false;
    private boolean editorWasPaused = false;
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private final List<Place> current = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);
        db = new PlaceDb(this);
        list = findViewById(R.id.list);
        title = findViewById(R.id.title);
        EditText search = findViewById(R.id.search);
        findViewById(R.id.back).setOnClickListener(v -> finish());

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { reload(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        list.setOnItemClickListener((parent, view, position, id) -> showPlace(current.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showPlace(current.get(position));
            return true;
        });

        reload("");
        if (getIntent().getBooleanExtra(EXTRA_START_ADD, false)) {
            getIntent().removeExtra(EXTRA_START_ADD);
            list.post(() -> openRealMapEditor());
        }
    }

    public void openAdd(boolean gps) { openRealMapEditor(); }

    private void openRealMapEditor() {
        Intent intent = new Intent(this, MainActivity.class);
intent.putExtra(MainActivity.EXTRA_OPEN_MAP, true);
intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
startActivity(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingEditorReturn && editorWasPaused) {
            pendingEditorReturn = false;
            editorWasPaused = false;
            io.execute(() -> {
                try {
                    java.util.List<Place> imported = MyMapsImporter.download();
                    if (!imported.isEmpty()) db.replaceMyMaps(imported);
                } catch (Exception ignored) { /* Preserve last known places on sync failures. */ }
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) reload(searchText());
                });
            });
        }
    }

    @Override protected void onPause() {
        if (pendingEditorReturn) editorWasPaused = true;
        super.onPause();
    }

    private String searchText() {
        EditText search = findViewById(R.id.search);
        return search.getText().toString();
    }

    private void showPlace(Place p) {
        String title = p.name;
        String coordinates = String.format(java.util.Locale.US, "%.6f, %.6f", p.lat, p.lon);
        boolean local = "local".equals(p.source);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage((local ? "Enregistré dans Visited sur ce téléphone" : "Importé de Google My Maps")
                        + "\n\nGPS : " + coordinates
                        + (local ? "\n\nCe lieu n’est pas ajouté automatiquement à ta carte Google My Maps." : ""))
                .setPositiveButton(local ? "Voir sur Google Maps" : "Modifier dans ma carte", (dialog, which) -> {
                    if (!local) {
                        openRealMapEditor();
                    } else {
                        Uri uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + p.lat + "%2C" + p.lon);
                        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                        catch (Exception e) { new AlertDialog.Builder(this).setMessage("Google Maps est indisponible.").setPositiveButton("OK",null).show(); }
                    }
                })
                .setNeutralButton(local ? "Supprimer" : "Fermer", (dialog, which) -> {
                    if (local) confirmDelete(p);
                })
                .setNegativeButton("Retour",null)
                .show();
    }

    private void confirmDelete(Place p) {
        new AlertDialog.Builder(this)
                .setTitle("Supprimer ce lieu de Visited ?")
                .setMessage(p.name + "\nCette suppression est définitive sur cet appareil.")
                .setPositiveButton("Supprimer", (d,w) -> { db.delete(p.id); reload(searchText()); })
                .setNegativeButton("Annuler", null).show();
    }

    private void reload(String q) {
        current.clear();
        current.addAll(db.search(q));
        title.setText("Lieux synchronisés · " + db.count());
        ArrayAdapter<Place> adapter = new ArrayAdapter<Place>(this, android.R.layout.simple_list_item_2, android.R.id.text1, current) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView t1 = v.findViewById(android.R.id.text1);
                TextView t2 = v.findViewById(android.R.id.text2);
                Place p = getItem(position);
                t1.setText(p.name);
                t1.setTextColor(Color.WHITE);
                t2.setText(("mymaps".equals(p.source) ? "Places Visited" : "Application") + " · " + String.format(java.util.Locale.getDefault(), "%.5f, %.5f", p.lat, p.lon));
                t2.setTextColor(Color.LTGRAY);
                v.setBackgroundColor(Color.rgb(16,17,20));
                return v;
            }
        };
        list.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }

    @Override protected void onDestroy() { io.shutdownNow(); if (db != null) db.close(); super.onDestroy(); }
}
