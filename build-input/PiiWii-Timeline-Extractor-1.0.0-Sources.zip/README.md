# PiiWii Timeline Extractor 1.0.0

APK de diagnostic/extraction locale de Google Maps Timeline (« Vos trajets »).

Fonctions :
- détecte Google Play Services / Google Maps ;
- détecte l'accès root ;
- avec root : copie `/data/data/com.google.android.gms/databases/odlh-storage.db` + WAL/SHM si présents et produit un ZIP dans Downloads ;
- sans root : recherche les exports Timeline/Takeout accessibles dans le stockage partagé ;
- permet de choisir manuellement un fichier et de le copier dans le ZIP d'export ;
- exporte un diagnostic lisible.

Important : Android interdit à une APK normale de lire les données privées d'une autre application. `MANAGE_EXTERNAL_STORAGE` ne donne pas accès à `/data/data/...`. L'extraction de la base privée nécessite donc un accès root/système.
