package ch.piiwii.timelineextractor;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_DOCUMENT = 42;
    private static final int REQ_STORAGE = 43;

    private TextView status;
    private TextView log;
    private Button exportButton;
    private Button shareButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<File> collectedFiles = new ArrayList<>();
    private final Set<String> collectedPaths = new HashSet<>();
    private Uri lastExportUri;
    private StringBuilder diagnostic = new StringBuilder();
    private File tempDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tempDir = new File(getExternalFilesDir(null), "timeline-extract");
        if (!tempDir.exists()) tempDir.mkdirs();
        buildUi();
        appendLog("PiiWii Timeline Extractor 1.0.0 prêt.");
        appendLog("Cette app ne suit pas votre position et ne demande pas la permission Localisation.");
        appendLog("Objectif : récupérer des données déjà présentes sur le téléphone.");
        refreshStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("PiiWii Timeline Extractor");
        title.setTextSize(25);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(8), 0, dp(6));
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Récupération locale de Google Maps « Vos trajets »");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFFCCCCCC);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(18));
        root.addView(subtitle, matchWrap());

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(15);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.setBackgroundColor(0xFF242424);
        root.addView(status, matchWrap());

        root.addView(button("1. Vérifier le téléphone", v -> refreshStatus()), buttonParams());
        root.addView(button("2. Autoriser l'accès complet aux fichiers", v -> requestAllFilesAccess()), buttonParams());

        exportButton = button("3. Chercher et extraire mes trajets", v -> startExtraction());
        root.addView(exportButton, buttonParams());

        root.addView(button("Choisir un export/fichier manuellement", v -> openDocument()), buttonParams());

        shareButton = button("Partager le dernier ZIP", v -> shareLastExport());
        shareButton.setEnabled(false);
        root.addView(shareButton, buttonParams());

        TextView note = new TextView(this);
        note.setText("Important : l'accès complet aux fichiers ne donne PAS accès aux données privées de Google. Si le téléphone est rooté, l'app peut demander l'autorisation root et copier la base Google Play Services. Sans root, elle recherche seulement les exports accessibles dans votre stockage.");
        note.setTextColor(0xFFFFD180);
        note.setTextSize(13);
        note.setPadding(dp(4), dp(12), dp(4), dp(12));
        root.addView(note, matchWrap());

        log = new TextView(this);
        log.setTextColor(0xFFB9F6CA);
        log.setTextSize(12);
        log.setPadding(dp(12), dp(12), dp(12), dp(12));
        log.setBackgroundColor(0xFF050505);
        log.setTextIsSelectable(true);
        root.addView(log, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(330)));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(15);
        if (Build.VERSION.SDK_INT >= 21) b.setBackgroundTintList(ColorStateList.valueOf(0xFFB00020));
        b.setOnClickListener(listener);
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        p.topMargin = dp(10);
        return p;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void refreshStatus() {
        worker.submit(() -> {
            boolean gms = isPackageInstalled("com.google.android.gms");
            boolean maps = isPackageInstalled("com.google.android.apps.maps");
            RootResult rr = testRoot();
            boolean files = hasAllFilesAccess();
            String text = "Google Play Services : " + yesNo(gms) +
                    "\nGoogle Maps : " + yesNo(maps) +
                    "\nAccès complet aux fichiers : " + yesNo(files) +
                    "\nAccès root : " + (rr.ok ? "OUI" : "NON / refusé") +
                    "\nAndroid : " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
            diag("STATUS | " + text.replace("\n", " | "));
            runOnUiThread(() -> status.setText(text));
        });
    }

    private boolean isPackageInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestAllFilesAccess() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            } else {
                toast("Autorisation déjà disponible sur cette version Android.");
            }
        } catch (Exception e) {
            if (Build.VERSION.SDK_INT >= 30) startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    private void openDocument() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OPEN_DOCUMENT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_DOCUMENT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            worker.submit(() -> importUri(uri));
        }
    }

    private void importUri(Uri uri) {
        try {
            File out = new File(tempDir, "manuel-" + System.currentTimeMillis() + guessExtension(uri));
            try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream fos = new FileOutputStream(out)) {
                if (in == null) throw new Exception("Flux inaccessible");
                copy(in, fos);
            }
            collect(out);
            appendLog("✓ Fichier manuel ajouté : " + out.getName() + " (" + human(out.length()) + ")");
            diag("MANUAL | " + uri + " -> " + out.getAbsolutePath());
        } catch (Exception e) {
            appendLog("✗ Import manuel impossible : " + e.getMessage());
            diag("MANUAL_ERROR | " + e);
        }
    }

    private String guessExtension(Uri uri) {
        String s = uri.toString().toLowerCase(Locale.ROOT);
        for (String ext : new String[]{".json", ".zip", ".db", ".csv", ".gpx", ".kml"}) if (s.contains(ext)) return ext;
        return ".bin";
    }

    private void startExtraction() {
        exportButton.setEnabled(false);
        lastExportUri = null;
        shareButton.setEnabled(false);
        worker.submit(() -> {
            try {
                appendLog("\n=== DÉBUT DE L'EXTRACTION ===");
                clearOldTemp();
                RootResult root = testRoot();
                appendLog(root.ok ? "✓ Accès root accordé." : "• Pas d'accès root (ou autorisation refusée)." );

                if (root.ok) {
                    extractRootDatabase();
                } else {
                    appendLog("Android protège /data/data/com.google.android.gms : aucune permission normale ne peut ouvrir ce dossier.");
                }

                scanSharedStorage();
                Uri exported = createExportZip();
                if (exported != null) {
                    lastExportUri = exported;
                    appendLog("✓ ZIP créé dans Téléchargements / PiiWii Timeline.");
                    diag("EXPORT_URI | " + exported);
                    runOnUiThread(() -> {
                        shareButton.setEnabled(true);
                        Toast.makeText(this, "ZIP créé dans Téléchargements", Toast.LENGTH_LONG).show();
                    });
                }
            } catch (Exception e) {
                appendLog("✗ Erreur : " + e.getClass().getSimpleName() + " - " + e.getMessage());
                diag("FATAL | " + e);
            } finally {
                runOnUiThread(() -> exportButton.setEnabled(true));
            }
        });
    }

    private void clearOldTemp() {
        File[] files = tempDir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.getName().startsWith("odlh-") || f.getName().startsWith("shared-")) f.delete();
            }
        }
    }

    private RootResult testRoot() {
        try {
            Process p = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
            String out = readAll(p.getInputStream());
            int code = p.waitFor();
            boolean ok = code == 0 && out.contains("uid=0");
            return new RootResult(ok, out.trim());
        } catch (Exception e) {
            return new RootResult(false, e.toString());
        }
    }

    private void extractRootDatabase() {
        String[] bases = new String[]{
                "/data/data/com.google.android.gms/databases/odlh-storage.db",
                "/data/user/0/com.google.android.gms/databases/odlh-storage.db",
                "/data/user_de/0/com.google.android.gms/databases/odlh-storage.db"
        };
        boolean found = false;
        for (String src : bases) {
            try {
                String marker = src.replace('/', '_').replace('.', '_');
                File db = new File(tempDir, "odlh-" + marker + ".db");
                File wal = new File(tempDir, db.getName() + "-wal");
                File shm = new File(tempDir, db.getName() + "-shm");
                String script =
                        "if [ -f '" + src + "' ]; then " +
                        "cp '" + src + "' '" + shq(db.getAbsolutePath()) + "'; chmod 644 '" + shq(db.getAbsolutePath()) + "'; " +
                        "[ -f '" + src + "-wal' ] && cp '" + src + "-wal' '" + shq(wal.getAbsolutePath()) + "' && chmod 644 '" + shq(wal.getAbsolutePath()) + "'; " +
                        "[ -f '" + src + "-shm' ] && cp '" + src + "-shm' '" + shq(shm.getAbsolutePath()) + "' && chmod 644 '" + shq(shm.getAbsolutePath()) + "'; " +
                        "echo FOUND; else echo MISSING; fi";
                Process p = new ProcessBuilder("su", "-c", script).redirectErrorStream(true).start();
                String out = readAll(p.getInputStream());
                int code = p.waitFor();
                diag("ROOT_COPY | " + src + " | code=" + code + " | " + out.trim());
                if (db.exists() && db.length() > 0) {
                    found = true;
                    collect(db);
                    if (wal.exists() && wal.length() > 0) collect(wal);
                    if (shm.exists() && shm.length() > 0) collect(shm);
                    appendLog("✓ Base Google trouvée : " + src);
                    appendLog("  Taille DB : " + human(db.length()) + (wal.exists() ? " | WAL : " + human(wal.length()) : ""));
                    if (hasSqliteHeader(db)) appendLog("  ✓ En-tête SQLite valide.");
                    else appendLog("  ! Le fichier n'a pas l'en-tête SQLite attendu.");
                    break;
                }
            } catch (Exception e) {
                diag("ROOT_COPY_ERROR | " + src + " | " + e);
            }
        }
        if (!found) appendLog("! Accès root présent, mais odlh-storage.db n'a pas été trouvée aux emplacements connus.");
    }

    private boolean hasSqliteHeader(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[16];
            int n = in.read(b);
            return n == 16 && new String(b, StandardCharsets.US_ASCII).startsWith("SQLite format 3");
        } catch (Exception e) { return false; }
    }

    private void scanSharedStorage() {
        appendLog("• Recherche des exports accessibles dans le stockage partagé...");
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            appendLog("  Accès complet aux fichiers non accordé : recherche limitée.");
        }
        File ext = Environment.getExternalStorageDirectory();
        List<File> roots = new ArrayList<>();
        roots.add(new File(ext, "Download"));
        roots.add(new File(ext, "Documents"));
        roots.add(new File(ext, "Téléchargements"));
        int[] visited = new int[]{0};
        int before = collectedFiles.size();
        for (File r : roots) scanDir(r, 0, 6, visited);
        int added = collectedFiles.size() - before;
        appendLog("  " + added + " fichier(s) Timeline/Takeout accessible(s) ajouté(s)." );
        diag("SCAN | visited=" + visited[0] + " | added=" + added);
    }

    private void scanDir(File dir, int depth, int maxDepth, int[] visited) {
        if (dir == null || depth > maxDepth || visited[0] > 25000 || !dir.exists() || !dir.canRead()) return;
        File[] children;
        try { children = dir.listFiles(); } catch (Exception e) { return; }
        if (children == null) return;
        for (File f : children) {
            if (visited[0]++ > 25000) return;
            if (f.isDirectory()) {
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.startsWith(".") || n.equals("android")) continue;
                scanDir(f, depth + 1, maxDepth, visited);
            } else if (isInteresting(f)) {
                try {
                    File out = new File(tempDir, "shared-" + Math.abs(f.getAbsolutePath().hashCode()) + "-" + safe(f.getName()));
                    copyFile(f, out);
                    collect(out);
                    appendLog("  ✓ " + f.getAbsolutePath() + " (" + human(f.length()) + ")");
                } catch (Exception e) {
                    diag("SCAN_COPY_ERROR | " + f + " | " + e);
                }
            }
        }
    }

    private boolean isInteresting(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        boolean ext = n.endsWith(".json") || n.endsWith(".zip") || n.endsWith(".db") || n.endsWith(".csv") || n.endsWith(".gpx") || n.endsWith(".kml");
        if (!ext) return false;
        return n.contains("timeline") || n.contains("takeout") || n.contains("trajet") || n.contains("location history") || n.contains("historique") || n.equals("records.json") || n.contains("odlh");
    }

    private void collect(File f) {
        try {
            String p = f.getCanonicalPath();
            if (collectedPaths.add(p)) collectedFiles.add(f);
        } catch (Exception e) {
            if (collectedPaths.add(f.getAbsolutePath())) collectedFiles.add(f);
        }
    }

    private Uri createExportZip() throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date());
        String name = "PiiWii-Timeline-Extract-" + stamp + ".zip";

        File diagnosticFile = new File(tempDir, "diagnostic.txt");
        try (BufferedWriter w = new BufferedWriter(new FileWriter(diagnosticFile, false))) {
            w.write("PiiWii Timeline Extractor 1.0.0\n");
            w.write("Date: " + new Date() + "\n");
            w.write("Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n");
            w.write("Android: " + Build.VERSION.RELEASE + " API " + Build.VERSION.SDK_INT + "\n\n");
            w.write(diagnostic.toString());
            w.write("\n\nFichiers collectés:\n");
            for (File f : collectedFiles) w.write("- " + f.getName() + " | " + f.length() + " octets\n");
        }

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PiiWii Timeline");
            cv.put(MediaStore.Downloads.IS_PENDING, 1);
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("Impossible de créer le ZIP dans Téléchargements");
            try (OutputStream os = cr.openOutputStream(uri); ZipOutputStream zos = new ZipOutputStream(os)) {
                zipFile(zos, diagnosticFile, "diagnostic.txt");
                for (File f : collectedFiles) zipFile(zos, f, "donnees/" + safe(f.getName()));
            }
            cv.clear();
            cv.put(MediaStore.Downloads.IS_PENDING, 0);
            cr.update(uri, cv, null, null);
            return uri;
        } else {
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(downloads, "PiiWii Timeline");
            dir.mkdirs();
            File out = new File(dir, name);
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
                zipFile(zos, diagnosticFile, "diagnostic.txt");
                for (File f : collectedFiles) zipFile(zos, f, "donnees/" + safe(f.getName()));
            }
            appendLog("ZIP : " + out.getAbsolutePath());
            return null;
        }
    }

    private void zipFile(ZipOutputStream zos, File f, String name) throws Exception {
        if (!f.exists() || !f.isFile()) return;
        ZipEntry e = new ZipEntry(name);
        e.setTime(f.lastModified());
        zos.putNextEntry(e);
        try (FileInputStream in = new FileInputStream(f)) { copy(in, zos); }
        zos.closeEntry();
    }

    private void shareLastExport() {
        if (lastExportUri == null) {
            toast("Aucun ZIP à partager.");
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_STREAM, lastExportUri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Partager le ZIP Timeline"));
    }

    private void copyFile(File src, File dst) throws Exception {
        try (FileInputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(dst)) { copy(in, out); }
    }

    private void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[1024 * 128];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
    }

    private String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private String shq(String s) { return s.replace("'", "'\\''"); }
    private String safe(String s) { return s.replaceAll("[^A-Za-z0-9._-]", "_"); }
    private String yesNo(boolean b) { return b ? "OUI" : "NON"; }

    private String human(long b) {
        if (b < 1024) return b + " o";
        double kb = b / 1024.0;
        if (kb < 1024) return String.format(Locale.FRANCE, "%.1f Ko", kb);
        return String.format(Locale.FRANCE, "%.1f Mo", kb / 1024.0);
    }

    private void appendLog(String s) {
        diag("LOG | " + s.replace("\n", " | "));
        runOnUiThread(() -> log.append(s + "\n"));
    }

    private synchronized void diag(String s) { diagnostic.append(new Date()).append(" | ").append(s).append('\n'); }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show()); }

    private static class RootResult {
        final boolean ok;
        final String output;
        RootResult(boolean ok, String output) { this.ok = ok; this.output = output; }
    }
}
