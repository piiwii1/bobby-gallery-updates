package ch.piiwii.timelineextractor;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.JsonReader;
import android.util.JsonToken;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int REQ_TIMELINE_JSON = 120;

    private TextView status;
    private Button extractButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<Candidate> candidates = new ArrayList<>();
    private boolean candidatesReady = false;
    private boolean waitingExternalReturn = false;
    private boolean actuallyLeftApp = false;
    private boolean pickerOpened = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        worker.submit(this::discoverGoogleScreens);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("PiiWii Timeline Extractor");
        title.setTextSize(25);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, matchWrap());

        TextView version = new TextView(this);
        version.setText("1.2.0 — Vos trajets Google");
        version.setTextSize(14);
        version.setTextColor(0xFFBDBDBD);
        version.setGravity(Gravity.CENTER_HORIZONTAL);
        version.setPadding(0, dp(5), 0, dp(28));
        root.addView(version, matchWrap());

        status = new TextView(this);
        status.setText("Prêt. Appuie sur le bouton ci-dessous.");
        status.setTextSize(16);
        status.setTextColor(0xFFFFFFFF);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(16), dp(18), dp(16), dp(18));
        status.setBackgroundColor(0xFF232323);
        root.addView(status, matchWrap());

        extractButton = new Button(this);
        extractButton.setText("EXTRAIRE MES TRAJETS");
        extractButton.setTextSize(18);
        extractButton.setTextColor(0xFFFFFFFF);
        if (Build.VERSION.SDK_INT >= 21) {
            extractButton.setBackgroundTintList(ColorStateList.valueOf(0xFFB00020));
        }
        extractButton.setOnClickListener(v -> startExtraction());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68));
        bp.topMargin = dp(22);
        root.addView(extractButton, bp);

        TextView help = new TextView(this);
        help.setText("L’app ouvre l’export Google. Après avoir enregistré les données, reviens ici : le fichier Timeline.json sera demandé une seule fois puis la sauvegarde sera créée automatiquement.");
        help.setTextSize(13);
        help.setTextColor(0xFFCCCCCC);
        help.setGravity(Gravity.CENTER_HORIZONTAL);
        help.setPadding(dp(6), dp(18), dp(6), 0);
        root.addView(help, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void startExtraction() {
        extractButton.setEnabled(false);
        pickerOpened = false;
        waitingExternalReturn = true;
        actuallyLeftApp = false;
        status.setText("Ouverture de Google / Localisation…\n\nDans l’écran qui s’ouvre, choisis « Exporter les données Timeline » puis enregistre le fichier.");

        worker.submit(() -> {
            if (!candidatesReady) discoverGoogleScreens();
            runOnUiThread(this::openGoogleExportOrLocation);
        });
    }

    private void discoverGoogleScreens() {
        candidates.clear();
        Set<String> seen = new HashSet<>();
        addKnown(seen, "com.google.android.gms", "com.google.android.location.settings.LocationHistorySettingsChimeraActivity", 200);
        addKnown(seen, "com.google.android.gms", "com.google.android.location.settings.LocationHistorySettingsActivity", 190);
        addKnown(seen, "com.google.android.gms", "com.google.android.gms.location.settings.LocationHistorySettingsActivity", 180);
        scanPackage("com.google.android.gms", seen);
        scanPackage("com.google.android.apps.maps", seen);
        Collections.sort(candidates, Comparator.comparingInt((Candidate c) -> c.score).reversed());
        candidatesReady = true;
    }

    private void scanPackage(String pkg, Set<String> seen) {
        try {
            PackageManager pm = getPackageManager();
            long flags = PackageManager.GET_ACTIVITIES | PackageManager.MATCH_DISABLED_COMPONENTS;
            PackageInfo info;
            if (Build.VERSION.SDK_INT >= 33) info = pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags));
            else info = pm.getPackageInfo(pkg, (int) flags);
            if (info.activities == null) return;
            for (ActivityInfo ai : info.activities) {
                if (ai.name == null || !ai.exported) continue;
                int score = scoreName(ai.name);
                if (score <= 0) continue;
                String key = pkg + "/" + ai.name;
                if (seen.add(key)) candidates.add(new Candidate(new ComponentName(pkg, ai.name), score));
            }
        } catch (Exception ignored) {}
    }

    private int scoreName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        int s = 0;
        if (n.contains("timeline")) s += 140;
        if (n.contains("locationhistory")) s += 130;
        if (n.contains("location_history")) s += 125;
        if (n.contains("history") && n.contains("location")) s += 90;
        if (n.contains("export")) s += 60;
        if (n.contains("settings")) s += 20;
        return s;
    }

    private void addKnown(Set<String> seen, String pkg, String cls, int score) {
        String key = pkg + "/" + cls;
        if (seen.add(key)) candidates.add(new Candidate(new ComponentName(pkg, cls), score));
    }

    private void openGoogleExportOrLocation() {
        for (Candidate c : candidates) {
            try {
                Intent i = new Intent();
                i.setComponent(c.component);
                startActivity(i);
                return;
            } catch (SecurityException | ActivityNotFoundException ignored) {
            } catch (Exception ignored) {}
        }
        try {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        } catch (Exception e) {
            waitingExternalReturn = false;
            extractButton.setEnabled(true);
            status.setText("Impossible d’ouvrir les réglages de localisation sur ce téléphone.");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (waitingExternalReturn) actuallyLeftApp = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitingExternalReturn && actuallyLeftApp && !pickerOpened) {
            waitingExternalReturn = false;
            pickerOpened = true;
            status.setText("Sélectionne maintenant le fichier Timeline.json que Google vient d’exporter.");
            status.postDelayed(this::pickTimelineJson, 450);
        }
    }

    private void pickTimelineJson() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream", "text/plain"});
            startActivityForResult(i, REQ_TIMELINE_JSON);
        } catch (Exception e) {
            extractButton.setEnabled(true);
            status.setText("Impossible d’ouvrir le sélecteur de fichier.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_TIMELINE_JSON) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            extractButton.setEnabled(true);
            status.setText("Aucun fichier sélectionné. Tu peux recommencer avec le bouton.");
            return;
        }

        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) {}

        String name = displayName(uri);
        status.setText("Analyse de " + name + "…");
        worker.submit(() -> analyzeAndBackup(uri, name));
    }

    private void analyzeAndBackup(Uri uri, String name) {
        try {
            Stats s = new Stats();
            s.fileBytes = querySize(uri);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 JsonReader r = new JsonReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                r.setLenient(true);
                readValue(r, s, null);
            }

            boolean real = s.semanticSegments > 0 || s.visits > 0 || s.activities > 0 ||
                    (s.minYear > 0 && s.maxYear > 0 && s.fileBytes > 10_000);

            if (!real) {
                runOnUiThread(() -> {
                    extractButton.setEnabled(true);
                    status.setText("Ce fichier n’est pas une vraie Timeline Google complète.\n\nAucune sauvegarde vide n’a été créée.");
                });
                return;
            }

            String outName = writeBackupZip(uri, name, s);
            runOnUiThread(() -> {
                extractButton.setEnabled(true);
                status.setText("✓ SAUVEGARDE CRÉÉE\n\n" + outName +
                        "\n\nPériode détectée : " + (s.minYear == 0 ? "?" : s.minYear) + " → " + (s.maxYear == 0 ? "?" : s.maxYear) +
                        "\nSegments : " + s.semanticSegments + " | Visites : " + s.visits +
                        "\n\nDossier : Téléchargements / PiiWii Timeline");
                toast("Sauvegarde Timeline terminée.");
            });
        } catch (Exception e) {
            runOnUiThread(() -> {
                extractButton.setEnabled(true);
                status.setText("Échec : le fichier sélectionné n’a pas pu être lu comme une Timeline Google.");
            });
        }
    }

    private void readValue(JsonReader r, Stats s, String key) throws Exception {
        JsonToken t = r.peek();
        if (t == JsonToken.BEGIN_OBJECT) {
            if ("visit".equalsIgnoreCase(key)) s.visits++;
            else if ("activity".equalsIgnoreCase(key)) s.activities++;
            else if ("timelinePath".equalsIgnoreCase(key)) s.timelinePaths++;
            r.beginObject();
            while (r.hasNext()) {
                String name = r.nextName();
                readValue(r, s, name);
            }
            r.endObject();
        } else if (t == JsonToken.BEGIN_ARRAY) {
            r.beginArray();
            if ("semanticSegments".equalsIgnoreCase(key)) {
                while (r.hasNext()) { s.semanticSegments++; readValue(r, s, "semanticSegment"); }
            } else {
                while (r.hasNext()) readValue(r, s, key);
            }
            r.endArray();
        } else if (t == JsonToken.STRING) {
            String v = r.nextString();
            if (key != null && key.toLowerCase(Locale.ROOT).contains("time")) updateYear(s, v);
        } else if (t == JsonToken.NUMBER) {
            String v = r.nextString();
            if (key != null && key.toLowerCase(Locale.ROOT).contains("time")) updateYear(s, v);
        } else if (t == JsonToken.BOOLEAN) r.nextBoolean();
        else if (t == JsonToken.NULL) r.nextNull();
        else r.skipValue();
    }

    private void updateYear(Stats s, String v) {
        if (v == null) return;
        for (int i = 0; i <= v.length() - 4; i++) {
            char a=v.charAt(i), b=v.charAt(i+1), c=v.charAt(i+2), d=v.charAt(i+3);
            if (!Character.isDigit(a)||!Character.isDigit(b)||!Character.isDigit(c)||!Character.isDigit(d)) continue;
            int y=(a-'0')*1000+(b-'0')*100+(c-'0')*10+(d-'0');
            if (y >= 2000 && y <= 2100) {
                if (s.minYear == 0 || y < s.minYear) s.minYear = y;
                if (s.maxYear == 0 || y > s.maxYear) s.maxYear = y;
                return;
            }
        }
    }

    private String writeBackupZip(Uri source, String sourceName, Stats s) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date());
        String outName = "PiiWii-Timeline-" + stamp + ".zip";
        File report = new File(getCacheDir(), "validation.txt");
        try (BufferedWriter w = new BufferedWriter(new FileWriter(report, false))) {
            w.write("PiiWii Timeline Extractor 1.2.0\n");
            w.write("Validation: OK\n");
            w.write("Source: " + sourceName + "\n");
            w.write("Taille: " + s.fileBytes + " octets\n");
            w.write("Segments: " + s.semanticSegments + "\n");
            w.write("Visites: " + s.visits + "\n");
            w.write("Activites: " + s.activities + "\n");
            w.write("Annee min: " + s.minYear + "\n");
            w.write("Annee max: " + s.maxYear + "\n");
        }

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, outName);
            cv.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PiiWii Timeline");
            cv.put(MediaStore.Downloads.IS_PENDING, 1);
            ContentResolver cr = getContentResolver();
            Uri out = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (out == null) throw new Exception("Création du ZIP impossible");
            try (OutputStream os = cr.openOutputStream(out); ZipOutputStream zos = new ZipOutputStream(os)) {
                addUriToZip(zos, source, safeJsonName(sourceName));
                addFileToZip(zos, report, "validation.txt");
            }
            cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0); cr.update(out, cv, null, null);
            return outName;
        }

        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "PiiWii Timeline");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, outName);
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            addUriToZip(zos, source, safeJsonName(sourceName));
            addFileToZip(zos, report, "validation.txt");
        }
        return outName;
    }

    private void addUriToZip(ZipOutputStream zos, Uri uri, String name) throws Exception {
        zos.putNextEntry(new ZipEntry(name));
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Source inaccessible");
            copy(in, zos);
        }
        zos.closeEntry();
    }

    private void addFileToZip(ZipOutputStream zos, File f, String name) throws Exception {
        zos.putNextEntry(new ZipEntry(name));
        try (InputStream in = new java.io.FileInputStream(f)) { copy(in, zos); }
        zos.closeEntry();
    }

    private String safeJsonName(String n) {
        String x = (n == null || n.trim().isEmpty()) ? "Timeline.json" : n.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!x.toLowerCase(Locale.ROOT).endsWith(".json")) x += ".json";
        return x;
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        return "Timeline.json";
    }

    private long querySize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) return c.getLong(i);
            }
        } catch (Exception ignored) {}
        return 0;
    }

    private void copy(InputStream in, OutputStream out) throws Exception {
        byte[] b = new byte[128 * 1024];
        int n;
        while ((n = in.read(b)) >= 0) out.write(b, 0, n);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }

    private static class Candidate {
        final ComponentName component;
        final int score;
        Candidate(ComponentName component, int score) { this.component = component; this.score = score; }
    }

    private static class Stats {
        long fileBytes;
        long semanticSegments;
        long visits;
        long activities;
        long timelinePaths;
        int minYear;
        int maxYear;
    }
}
