# PiiWii Timeline Extractor 1.2.0

Version simplifiée : un seul bouton.

1. Appuyer sur **EXTRAIRE MES TRAJETS**.
2. L'application ouvre l'écran Google/Android lié à l'historique de positions, avec repli vers les réglages de localisation.
3. Après l'export Google, revenir dans l'application.
4. Le sélecteur demande une seule fois `Timeline.json`.
5. Le fichier est validé puis sauvegardé automatiquement dans `Téléchargements/PiiWii Timeline`.

L'application refuse de créer une sauvegarde si le fichier ne contient pas de données Timeline reconnues.
