package ch.piiwii.timelineextractor;

import android.app.*;import android.os.*;import android.provider.Settings;import android.content.*;import android.net.Uri;import android.graphics.Color;import android.view.*;import android.widget.*;import java.io.*;import java.text.*;import java.util.*;import java.util.zip.*;import android.content.ContentValues;import android.provider.MediaStore;import android.os.Environment;

public class MainActivity extends Activity {
 TextView status; Button start,stop,export,access,maps;
 @Override public void onCreate(Bundle b){super.onCreate(b); build(); refresh();}
 void build(){ ScrollView sc=new ScrollView(this); LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(18),dp(18),dp(18),dp(18)); sc.addView(r);
  TextView t=new TextView(this);t.setText("PiiWii Timeline Extractor 1.1.0");t.setTextSize(24);t.setTextColor(Color.BLACK);r.addView(t);
  TextView d=new TextView(this);d.setText("Cette version ne tente plus d'ouvrir les dossiers privés Google. Elle lit uniquement ce que Google Maps affiche dans « Vos trajets », grâce à l'autorisation Accessibilité, puis enregistre les journées dans un fichier exportable.\n\nPour récupérer 2019 → aujourd'hui : activez l'accessibilité, ouvrez Vos trajets, choisissez votre première date de 2019, puis lancez le mode automatique.");d.setTextSize(16);d.setPadding(0,dp(12),0,dp(12));r.addView(d);
  access=btn("1. Activer l'accès Accessibilité",r); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
  maps=btn("2. Ouvrir Google Maps",r); maps.setOnClickListener(v->openMaps());
  start=btn("3. Démarrer la capture + jour suivant automatique",r); start.setOnClickListener(v->{getSharedPreferences("cap",0).edit().putBoolean("enabled",true).putBoolean("auto",true).apply(); toast("Capture activée. Retournez dans Google Maps Vos trajets.");refresh();openMaps();});
  stop=btn("Arrêter la capture",r); stop.setOnClickListener(v->{getSharedPreferences("cap",0).edit().putBoolean("enabled",false).apply();refresh();});
  export=btn("Exporter le ZIP",r);export.setOnClickListener(v->doExport());
  status=new TextView(this);status.setTextSize(15);status.setPadding(0,dp(16),0,dp(10));r.addView(status);setContentView(sc);
 }
 Button btn(String s,LinearLayout r){Button b=new Button(this);b.setText(s);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58));p.topMargin=dp(8);r.addView(b,p);return b;}
 void refresh(){if(status==null)return;boolean on=getSharedPreferences("cap",0).getBoolean("enabled",false);File f=MapsAccessibilityService.captureFile(this);long n=countLines(f);status.setText("Capture : "+(on?"ACTIVE":"arrêtée")+"\nJournées/écrans enregistrés : "+n+"\nFichier interne : "+f.getName());}
 long countLines(File f){if(!f.exists())return 0;long n=0;try(BufferedReader br=new BufferedReader(new FileReader(f))){while(br.readLine()!=null)n++;}catch(Exception ignored){}return n;}
 void openMaps(){try{Intent i=getPackageManager().getLaunchIntentForPackage("com.google.android.apps.maps");if(i!=null)startActivity(i);else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")));}catch(Exception e){toast(e.getMessage());}}
 void doExport(){try{File cap=MapsAccessibilityService.captureFile(this);if(!cap.exists()){toast("Aucune capture pour l'instant.");return;}File report=new File(getCacheDir(),"LISEZ-MOI.txt");try(FileWriter w=new FileWriter(report)){w.write("PiiWii Timeline Extractor 1.1.0\nCapture de l'interface Google Maps Vos trajets.\nChaque ligne JSON contient un instant, les textes visibles, descriptions et identifiants de vues.\nCette méthode n'accède pas aux données privées de Google Play Services.\n");}
   File z=new File(getCacheDir(),"timeline-ui.zip");try(ZipOutputStream zo=new ZipOutputStream(new FileOutputStream(z))){add(zo,cap);add(zo,report);}String name="PiiWii-Timeline-UI-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".zip";ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,name);cv.put(MediaStore.Downloads.MIME_TYPE,"application/zip");cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/PiiWii Timeline");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);try(InputStream in=new FileInputStream(z);OutputStream out=getContentResolver().openOutputStream(u)){byte[] b=new byte[65536];int q;while((q=in.read(b))>0)out.write(b,0,q);}toast("ZIP créé dans Téléchargements/PiiWii Timeline");refresh();
  }catch(Exception e){toast("Export impossible : "+e.getMessage());}}
 void add(ZipOutputStream z,File f)throws Exception{z.putNextEntry(new ZipEntry(f.getName()));try(InputStream in=new FileInputStream(f)){byte[]b=new byte[65536];int q;while((q=in.read(b))>0)z.write(b,0,q);}z.closeEntry();}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
 @Override protected void onResume(){super.onResume();refresh();}
}
